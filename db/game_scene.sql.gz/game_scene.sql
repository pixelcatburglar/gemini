-- Gemini 665 PostgreSQL table: game_scene
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_scene" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "itemID" BIGINT,
  "typeID" BIGINT,
  "groupID" BIGINT,
  "categoryID" BIGINT,
  "itemName" TEXT,
  "orbitID" TEXT,
  "orbitRadius" DOUBLE PRECISION,
  "radius" DOUBLE PRECISION,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_scene" ("_ordinal","_shape","_kinds","itemID","typeID","groupID","categoryID","itemName","orbitID","orbitRadius","radius") VALUES
(0,'dict','["int","int","int","int","bytes","none","float","float"]',64000055,1,15,3,'Flodinus Station',NULL,0,1500),
(1,'dict','["int","int","int","int","bytes","none","float","float"]',40088050,2,7,2,'Flodinus I',NULL,300000,100000),
(2,'dict','["int","int","int","int","bytes","none","float","float"]',40088051,2,7,2,'Flodinus II',NULL,375583.8991571955,100000),
(3,'dict','["int","int","int","int","bytes","none","float","float"]',40088052,2,7,2,'Flodinus III',NULL,442857.14285714284,100000),
(4,'dict','["int","int","int","int","bytes","none","float","float"]',40088053,2,7,2,'Flodinus IV',NULL,520039.2449868862,100000),
(5,'dict','["int","int","int","int","bytes","none","float","float"]',40088054,2,7,2,'Flodinus V',NULL,585714.2857142857,100000),
(6,'dict','["int","int","int","int","bytes","none","float","float"]',40088055,2,7,2,'Flodinus VI',NULL,664494.5908165768,100000),
(7,'dict','["int","int","int","int","bytes","none","float","float"]',40088056,2,7,2,'Flodinus VII',NULL,728571.4285714286,100000),
(8,'dict','["int","int","int","int","bytes","none","float","float"]',40088057,2,7,2,'Flodinus VIII',NULL,808949.9366462674,100000);
CREATE  INDEX "pg_game_scene_0" ON "game_scene"("itemID");
COMMIT;
