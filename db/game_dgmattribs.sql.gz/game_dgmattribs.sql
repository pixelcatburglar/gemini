-- Gemini 665 PostgreSQL table: game_dgmattribs
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_dgmattribs" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "attributeID" BIGINT,
  "attributeName" TEXT,
  "displayName" TEXT,
  "description" TEXT,
  "defaultValue" BIGINT,
  "published" BIGINT,
  "chargeRechargeTimeID" TEXT,
  "maxAttributeID" TEXT,
  "attributeCategory" TEXT,
  "unitID" BIGINT,
  "graphicID" TEXT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_dgmattribs" ("_ordinal","_shape","_kinds","attributeID","attributeName","displayName","description","defaultValue","published","chargeRechargeTimeID","maxAttributeID","attributeCategory","unitID","graphicID") VALUES
(0,'list','["int","bytes","bytes","bytes","int","int","none","none","none","none","none"]',10001,'mainColor','Main Color','',8030361,1,NULL,NULL,NULL,NULL,NULL),
(1,'list','["int","bytes","bytes","bytes","none","int","none","none","none","int","none"]',9011,'mass','Mass','',NULL,0,NULL,NULL,NULL,109,NULL),
(2,'list','["int","bytes","bytes","bytes","none","int","none","none","none","int","none"]',9005,'capacity','Capacity','',NULL,0,NULL,NULL,NULL,110,NULL),
(3,'list','["int","bytes","bytes","bytes","none","int","none","none","none","int","none"]',9017,'volume','Volume','',NULL,0,NULL,NULL,NULL,110,NULL),
(4,'list','["int","bytes","bytes","bytes","none","int","none","none","none","int","none"]',9013,'maxVelocity','Max Velocity','',NULL,1,NULL,NULL,NULL,111,NULL),
(5,'list','["int","bytes","bytes","bytes","none","int","none","none","none","none","none"]',9012,'maxPassengers','Max Passengers','',NULL,1,NULL,NULL,NULL,NULL,NULL),
(6,'list','["int","bytes","bytes","bytes","none","int","none","none","none","none","none"]',9008,'hiSlots','High Power Slots','',NULL,1,NULL,NULL,NULL,NULL,NULL),
(7,'list','["int","bytes","bytes","bytes","none","int","none","none","none","none","none"]',9014,'medSlots','Medium Power Slots','',NULL,1,NULL,NULL,NULL,NULL,NULL),
(8,'list','["int","bytes","bytes","bytes","none","int","none","none","none","none","none"]',9010,'lowSlots','Low Power Slots','',NULL,1,NULL,NULL,NULL,NULL,NULL),
(9,'list','["int","bytes","bytes","bytes","none","int","none","none","none","none","none"]',9016,'turretSlotsLeft','Turret Hardpoints','',NULL,1,NULL,NULL,NULL,NULL,NULL),
(10,'list','["int","bytes","bytes","bytes","none","int","none","none","none","none","none"]',9009,'launcherSlotsLeft','Launcher Hardpoints','',NULL,1,NULL,NULL,NULL,NULL,NULL),
(11,'list','["int","bytes","bytes","bytes","none","int","none","none","none","none","none"]',9007,'droneBaySlotsLeft','Drone Bay Slots','',NULL,1,NULL,NULL,NULL,NULL,NULL),
(12,'list','["int","bytes","bytes","bytes","none","int","none","none","none","int","none"]',9006,'cpu','CPU Usage','',NULL,1,NULL,NULL,NULL,112,NULL),
(13,'list','["int","bytes","bytes","bytes","none","int","none","none","none","int","none"]',9015,'power','Powergrid Usage','',NULL,1,NULL,NULL,NULL,113,NULL),
(14,'list','["int","bytes","bytes","bytes","int","int","none","none","none","none","none"]',10002,'charge','charge','',0,0,NULL,NULL,NULL,NULL,NULL),
(15,'list','["int","bytes","bytes","bytes","int","int","none","none","none","none","none"]',10003,'hp','hp','',0,0,NULL,NULL,NULL,NULL,NULL),
(16,'list','["int","bytes","bytes","bytes","int","int","none","none","none","none","none"]',10004,'damage','damage','',0,0,NULL,NULL,NULL,NULL,NULL),
(17,'list','["int","bytes","bytes","bytes","int","int","none","none","none","none","none"]',10005,'cpuLoad','cpuLoad','',0,0,NULL,NULL,NULL,NULL,NULL),
(18,'list','["int","bytes","bytes","bytes","int","int","none","none","none","none","none"]',10006,'cpuOutput','cpuOutput','',0,0,NULL,NULL,NULL,NULL,NULL),
(19,'list','["int","bytes","bytes","bytes","int","int","none","none","none","none","none"]',10007,'powerLoad','powerLoad','',0,0,NULL,NULL,NULL,NULL,NULL),
(20,'list','["int","bytes","bytes","bytes","int","int","none","none","none","none","none"]',10008,'powerOutput','powerOutput','',0,0,NULL,NULL,NULL,NULL,NULL);
CREATE  INDEX "pg_game_dgmattribs_0" ON "game_dgmattribs"("attributeID");
COMMIT;
