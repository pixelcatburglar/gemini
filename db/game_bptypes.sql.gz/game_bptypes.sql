-- Gemini 665 PostgreSQL table: game_bptypes
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_bptypes" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "blueprintTypeID" TEXT,
  "parentBlueprintTypeID" TEXT,
  "productTypeID" TEXT,
  PRIMARY KEY ("_ordinal")
);
CREATE  INDEX "pg_game_bptypes_0" ON "game_bptypes"("blueprintTypeID");
COMMIT;
