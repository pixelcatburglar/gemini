-- Gemini 665 PostgreSQL table: inventory
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "inventory" (
  "itemID" BIGINT,
  "ownerID" BIGINT NOT NULL,
  "locationID" BIGINT NOT NULL,
  "typeID" BIGINT NOT NULL,
  "flag" BIGINT NOT NULL DEFAULT 0,
  "quantity" BIGINT NOT NULL DEFAULT 1,
  "singleton" BIGINT NOT NULL DEFAULT 1,
  PRIMARY KEY ("itemID")
);
INSERT INTO "inventory" ("itemID","ownerID","locationID","typeID","flag","quantity","singleton") VALUES
(91000001,90000001,64000055,587,4,1,1),
(91000002,90000002,64000055,587,4,1,1),
(91000003,90000003,64000055,587,4,1,1),
(91000004,90000002,64000055,651,4,1,1),
(91000005,90000003,64000055,651,4,1,1),
(91000006,90000003,91000005,20065,9040,1,0);
CREATE  INDEX "pg_inventory_0" ON "inventory"("locationID");
CREATE  INDEX "pg_inventory_1" ON "inventory"("ownerID");
COMMIT;
