-- Gemini 665 PostgreSQL table: game_school_degrees
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_school_degrees" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "raceID" BIGINT,
  "schoolID" BIGINT,
  "agentTypeID" BIGINT,
  "attributeID" BIGINT,
  "attributeValue" BIGINT,
  "bonusTypeID" TEXT,
  "description" TEXT,
  "skillTypeID1" TEXT,
  "skillTypeID2" TEXT,
  "skillTypeID3" TEXT,
  "skillTypeID4" TEXT,
  "skillTypeID5" TEXT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_school_degrees" ("_ordinal","_shape","_kinds","raceID","schoolID","agentTypeID","attributeID","attributeValue","bonusTypeID","description","skillTypeID1","skillTypeID2","skillTypeID3","skillTypeID4","skillTypeID5") VALUES
(0,'list','["int","int","int","int","int","none","bytes","none","none","none","none","none"]',1,1,1,1,0,NULL,'',NULL,NULL,NULL,NULL,NULL),
(1,'list','["int","int","int","int","int","none","bytes","none","none","none","none","none"]',1,2,1,1,0,NULL,'',NULL,NULL,NULL,NULL,NULL),
(2,'list','["int","int","int","int","int","none","bytes","none","none","none","none","none"]',1,4,1,1,0,NULL,'',NULL,NULL,NULL,NULL,NULL),
(3,'list','["int","int","int","int","int","none","bytes","none","none","none","none","none"]',1,8,1,1,0,NULL,'',NULL,NULL,NULL,NULL,NULL),
(4,'list','["int","int","int","int","int","none","bytes","none","none","none","none","none"]',2,1,1,1,0,NULL,'',NULL,NULL,NULL,NULL,NULL),
(5,'list','["int","int","int","int","int","none","bytes","none","none","none","none","none"]',2,2,1,1,0,NULL,'',NULL,NULL,NULL,NULL,NULL),
(6,'list','["int","int","int","int","int","none","bytes","none","none","none","none","none"]',2,4,1,1,0,NULL,'',NULL,NULL,NULL,NULL,NULL),
(7,'list','["int","int","int","int","int","none","bytes","none","none","none","none","none"]',2,8,1,1,0,NULL,'',NULL,NULL,NULL,NULL,NULL),
(8,'list','["int","int","int","int","int","none","bytes","none","none","none","none","none"]',4,1,1,1,0,NULL,'',NULL,NULL,NULL,NULL,NULL),
(9,'list','["int","int","int","int","int","none","bytes","none","none","none","none","none"]',4,2,1,1,0,NULL,'',NULL,NULL,NULL,NULL,NULL),
(10,'list','["int","int","int","int","int","none","bytes","none","none","none","none","none"]',4,4,1,1,0,NULL,'',NULL,NULL,NULL,NULL,NULL),
(11,'list','["int","int","int","int","int","none","bytes","none","none","none","none","none"]',4,8,1,1,0,NULL,'',NULL,NULL,NULL,NULL,NULL),
(12,'list','["int","int","int","int","int","none","bytes","none","none","none","none","none"]',8,1,1,1,0,NULL,'',NULL,NULL,NULL,NULL,NULL),
(13,'list','["int","int","int","int","int","none","bytes","none","none","none","none","none"]',8,2,1,1,0,NULL,'',NULL,NULL,NULL,NULL,NULL),
(14,'list','["int","int","int","int","int","none","bytes","none","none","none","none","none"]',8,4,1,1,0,NULL,'',NULL,NULL,NULL,NULL,NULL),
(15,'list','["int","int","int","int","int","none","bytes","none","none","none","none","none"]',8,8,1,1,0,NULL,'',NULL,NULL,NULL,NULL,NULL);
CREATE  INDEX "pg_game_school_degrees_0" ON "game_school_degrees"("raceID");
COMMIT;
