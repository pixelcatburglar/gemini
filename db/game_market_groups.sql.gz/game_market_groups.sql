-- Gemini 665 PostgreSQL table: game_market_groups
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_market_groups" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "marketGroupID" BIGINT,
  "parentGroupID" BIGINT,
  "marketGroupName" TEXT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_market_groups" ("_ordinal","_shape","_kinds","marketGroupID","parentGroupID","marketGroupName") VALUES
(0,'tuple','["int","none","bytes"]',30000,NULL,'Ships'),
(1,'tuple','["int","int","bytes"]',30001,30000,'Frigates'),
(2,'tuple','["int","int","bytes"]',30002,30000,'Cruisers'),
(3,'tuple','["int","int","bytes"]',30003,30000,'Battleships'),
(4,'tuple','["int","int","bytes"]',30004,30000,'Industrials'),
(5,'tuple','["int","none","bytes"]',30005,NULL,'Ship Equipment'),
(6,'tuple','["int","int","bytes"]',30006,30005,'Turrets'),
(7,'tuple','["int","int","bytes"]',30007,30005,'Missile Launchers'),
(8,'tuple','["int","int","bytes"]',30008,30005,'Mining Lasers'),
(9,'tuple','["int","int","bytes"]',30009,30005,'Turret Accessories'),
(10,'tuple','["int","int","bytes"]',30010,30005,'Shield Systems'),
(11,'tuple','["int","int","bytes"]',30011,30005,'Armor Systems'),
(12,'tuple','["int","int","bytes"]',30012,30005,'Structure Systems'),
(13,'tuple','["int","int","bytes"]',30013,30005,'Powercores'),
(14,'tuple','["int","int","bytes"]',30014,30005,'Propulsion Systems'),
(15,'tuple','["int","int","bytes"]',30015,30005,'Sensor Systems'),
(16,'tuple','["int","int","bytes"]',30016,30005,'Cargo Systems'),
(17,'tuple','["int","int","bytes"]',30017,30005,'Capsule Systems'),
(18,'tuple','["int","none","bytes"]',30018,NULL,'Ammunition & Charges'),
(19,'tuple','["int","int","bytes"]',30019,30018,'Missiles'),
(20,'tuple','["int","int","bytes"]',30020,30018,'Mines'),
(21,'tuple','["int","none","bytes"]',30021,NULL,'Drones'),
(22,'tuple','["int","int","bytes"]',30022,30021,'Combat Drones'),
(23,'tuple','["int","int","bytes"]',30023,30021,'Mining Drones'),
(24,'tuple','["int","none","bytes"]',30024,NULL,'Trade Goods'),
(25,'tuple','["int","int","bytes"]',30025,30024,'Minerals'),
(26,'tuple','["int","int","bytes"]',30026,30024,'Ore'),
(27,'tuple','["int","int","bytes"]',30027,30024,'Commodities');
CREATE  INDEX "pg_game_market_groups_0" ON "game_market_groups"("marketGroupID");
COMMIT;
