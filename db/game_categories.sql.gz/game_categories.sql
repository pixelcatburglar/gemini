-- Gemini 665 PostgreSQL table: game_categories
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_categories" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "categoryID" BIGINT,
  "categoryName" TEXT,
  "description" TEXT,
  "published" BIGINT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_categories" ("_ordinal","_shape","_kinds","categoryID","categoryName","description","published") VALUES
(0,'list','["int","bytes","bytes","int"]',6,'Ship','',1),
(1,'list','["int","bytes","bytes","int"]',3,'Station','',1),
(2,'list','["int","bytes","bytes","int"]',2,'Celestial','',1),
(3,'list','["int","bytes","bytes","int"]',16,'Skill','',1),
(4,'list','["int","bytes","bytes","int"]',4,'Material','',1),
(5,'list','["int","bytes","bytes","int"]',11,'Entity','',1),
(6,'list','["int","bytes","bytes","int"]',5,'Accessories','',1),
(7,'list','["int","bytes","bytes","int"]',7,'Module','',1),
(8,'list','["int","bytes","bytes","int"]',8,'Charge','',1),
(9,'list','["int","bytes","bytes","int"]',10,'Trading','',1),
(10,'list','["int","bytes","bytes","int"]',17,'Commodity','',1),
(11,'list','["int","bytes","bytes","int"]',18,'Drone','',1),
(12,'list','["int","bytes","bytes","int"]',25,'Asteroid','',1);
CREATE UNIQUE INDEX "pg_game_categories_0" ON "game_categories"("categoryID");
CREATE  INDEX "pg_game_categories_1" ON "game_categories"("categoryID");
COMMIT;
