-- Gemini 665 PostgreSQL table: game_constants
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_constants" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "constantID" TEXT,
  "constantValue" BIGINT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_constants" ("_ordinal","_shape","_kinds","constantID","constantValue") VALUES
(0,'list','["bytes","int"]','ixItemID',0),
(1,'list','["bytes","int"]','ixTypeID',1),
(2,'list','["bytes","int"]','ixOwnerID',2),
(3,'list','["bytes","int"]','ixLocationID',3),
(4,'list','["bytes","int"]','ixFlag',4),
(5,'list','["bytes","int"]','ixContraband',5),
(6,'list','["bytes","int"]','ixSingleton',6),
(7,'list','["bytes","int"]','ixQuantity',7),
(8,'list','["bytes","int"]','ixGroupID',8),
(9,'list','["bytes","int"]','ixCategoryID',9),
(10,'list','["bytes","int"]','ixCustomInfo',10),
(11,'list','["bytes","int"]','containerHangar',4),
(12,'list','["bytes","int"]','categoryShip',6),
(13,'list','["bytes","int"]','categoryStation',3),
(14,'list','["bytes","int"]','categoryEntity',11),
(15,'list','["bytes","int"]','groupCapsule',29),
(16,'list','["bytes","int"]','groupCharacter',1),
(17,'list','["bytes","int"]','groupStation',15),
(18,'list','["bytes","int"]','groupStargate',10),
(19,'list','["bytes","int"]','groupMiningDrone',101),
(20,'list','["bytes","int"]','groupCombatDrone',100),
(21,'list','["bytes","int"]','categoryBlueprint',9),
(22,'list','["bytes","int"]','flagHangar',4),
(23,'list','["bytes","int"]','flagSlotFirst',9800),
(24,'list','["bytes","int"]','flagSlotLast',9899),
(25,'list','["bytes","int"]','flagFactorySlotFirst',9900),
(26,'list','["bytes","int"]','ixLauncherChargeItem',0),
(27,'list','["bytes","int"]','simulationTimeStep',500),
(28,'list','["bytes","int"]','groupShield',1016),
(29,'list','["bytes","int"]','groupArmor',1017),
(30,'list','["bytes","int"]','groupCapacitor',1020),
(31,'list','["bytes","int"]','groupComputer',1022),
(32,'list','["bytes","int"]','groupPowerCore',1019),
(33,'list','["bytes","int"]','flagHiSlot0',9800),
(34,'list','["bytes","int"]','flagHiSlot1',9801),
(35,'list','["bytes","int"]','flagHiSlot2',9802),
(36,'list','["bytes","int"]','flagHiSlot3',9803),
(37,'list','["bytes","int"]','flagHiSlot4',9804),
(38,'list','["bytes","int"]','flagHiSlot5',9805),
(39,'list','["bytes","int"]','flagHiSlot6',9806),
(40,'list','["bytes","int"]','flagHiSlot7',9807),
(41,'list','["bytes","int"]','flagMedSlot0',9808),
(42,'list','["bytes","int"]','flagMedSlot1',9809),
(43,'list','["bytes","int"]','flagMedSlot2',9810),
(44,'list','["bytes","int"]','flagMedSlot3',9811),
(45,'list','["bytes","int"]','flagMedSlot4',9812),
(46,'list','["bytes","int"]','flagMedSlot5',9813),
(47,'list','["bytes","int"]','flagMedSlot6',9814),
(48,'list','["bytes","int"]','flagMedSlot7',9815),
(49,'list','["bytes","int"]','flagLoSlot0',9816),
(50,'list','["bytes","int"]','flagLoSlot1',9817),
(51,'list','["bytes","int"]','flagLoSlot2',9818),
(52,'list','["bytes","int"]','flagLoSlot3',9819),
(53,'list','["bytes","int"]','flagLoSlot4',9820),
(54,'list','["bytes","int"]','flagLoSlot5',9821),
(55,'list','["bytes","int"]','flagLoSlot6',9822),
(56,'list','["bytes","int"]','flagLoSlot7',9823),
(57,'list','["bytes","int"]','activityCopying',9000),
(58,'list','["bytes","int"]','activityManufacturing',9001),
(59,'list','["bytes","int"]','activityResearchingMineralProductivity',9002),
(60,'list','["bytes","int"]','activityResearchingTechnology',9003),
(61,'list','["bytes","int"]','activityResearchingTimeProductivity',9004),
(62,'list','["bytes","int"]','attributeCapacity',9005),
(63,'list','["bytes","int"]','attributeCpu',9006),
(64,'list','["bytes","int"]','attributeDroneBaySlotsLeft',9007),
(65,'list','["bytes","int"]','attributeHiSlots',9008),
(66,'list','["bytes","int"]','attributeLauncherSlotsLeft',9009),
(67,'list','["bytes","int"]','attributeLowSlots',9010),
(68,'list','["bytes","int"]','attributeMass',9011),
(69,'list','["bytes","int"]','attributeMaxPassengers',9012),
(70,'list','["bytes","int"]','attributeMaxVelocity',9013),
(71,'list','["bytes","int"]','attributeMedSlots',9014),
(72,'list','["bytes","int"]','attributePower',9015),
(73,'list','["bytes","int"]','attributeTurretSlotsLeft',9016),
(74,'list','["bytes","int"]','attributeVolume',9017),
(75,'list','["bytes","int"]','categoryAccessories',9018),
(76,'list','["bytes","int"]','categoryCelestial',9019),
(77,'list','["bytes","int"]','categoryCharge',9020),
(78,'list','["bytes","int"]','categoryModule',9021),
(79,'list','["bytes","int"]','categoryTrading',9022),
(80,'list','["bytes","int"]','containerFactory',9023),
(81,'list','["bytes","int"]','containerGlobal',9024),
(82,'list','["bytes","int"]','containerScrapHeap',9025),
(83,'list','["bytes","int"]','containerShip',9026),
(84,'list','["bytes","int"]','containerStationCharacters',9027),
(85,'list','["bytes","int"]','containerWallet',9028),
(86,'list','["bytes","int"]','crpApplicationAcceptedByCharacter',9029),
(87,'list','["bytes","int"]','crpApplicationAcceptedByCorporation',9030),
(88,'list','["bytes","int"]','crpApplicationAppliedByCharacter',9031),
(89,'list','["bytes","int"]','crpApplicationRejectedByCharacter',9032),
(90,'list','["bytes","int"]','crpApplicationRejectedByCorporation',9033),
(91,'list','["bytes","int"]','crpApplicationRenegotiatedByCharacter',9034),
(92,'list','["bytes","int"]','crpApplicationRenegotiatedByCorporation',9035),
(93,'list','["bytes","int"]','dgmTauConstant',9036),
(94,'list','["bytes","int"]','effectHiPower',9037),
(95,'list','["bytes","int"]','effectLoPower',9038),
(96,'list','["bytes","int"]','effectMedPower',9039),
(97,'list','["bytes","int"]','flagAutoFit',9040),
(98,'list','["bytes","int"]','flagCargo',9041),
(99,'list','["bytes","int"]','flagConnected',9042),
(100,'list','["bytes","int"]','flagFixedSlot',9043),
(101,'list','["bytes","int"]','flagMarket',9044),
(102,'list','["bytes","int"]','flagPassenger',9045),
(103,'list','["bytes","int"]','flagPilot',9046),
(104,'list','["bytes","int"]','flagReward',9047),
(105,'list','["bytes","int"]','flagWallet',9048),
(106,'list','["bytes","int"]','frequencyDay',9049),
(107,'list','["bytes","int"]','frequencyHour',9050),
(108,'list','["bytes","int"]','frequencyMinute15',9051),
(109,'list','["bytes","int"]','frequencyWeek',9052),
(110,'list','["bytes","int"]','gangLeaderRole',9053),
(111,'list','["bytes","int"]','groupAmmo',9054),
(112,'list','["bytes","int"]','groupAsteroid',9055),
(113,'list','["bytes","int"]','groupAsteroidBelt',9056),
(114,'list','["bytes","int"]','groupBattleship',9057),
(115,'list','["bytes","int"]','groupBiomass',9058),
(116,'list','["bytes","int"]','groupCapacitorBooster',9059),
(117,'list','["bytes","int"]','groupCargoContainer',9060),
(118,'list','["bytes","int"]','groupCloud',9061),
(119,'list','["bytes","int"]','groupCorporation',9062),
(120,'list','["bytes","int"]','groupCruiser',9063),
(121,'list','["bytes","int"]','groupDroneLauncher',9064),
(122,'list','["bytes","int"]','groupEnergyWeapon',9065),
(123,'list','["bytes","int"]','groupHybridWeapon',9066),
(124,'list','["bytes","int"]','groupIndustrial',9067),
(125,'list','["bytes","int"]','groupLargeCollidableObject',9068),
(126,'list','["bytes","int"]','groupMine',9069),
(127,'list','["bytes","int"]','groupMineral',9070),
(128,'list','["bytes","int"]','groupMiningLaser',9071),
(129,'list','["bytes","int"]','groupMissile',9072),
(130,'list','["bytes","int"]','groupMissileLauncher',9073),
(131,'list','["bytes","int"]','groupMoney',9074),
(132,'list','["bytes","int"]','groupMoon',9075),
(133,'list','["bytes","int"]','groupPirateDrone',9076),
(134,'list','["bytes","int"]','groupPlanet',9077),
(135,'list','["bytes","int"]','groupPoliceDrone',9078),
(136,'list','["bytes","int"]','groupProjectileWeapon',9079),
(137,'list','["bytes","int"]','groupPropulsion',9080),
(138,'list','["bytes","int"]','groupProtectiveSentryGun',9081),
(139,'list','["bytes","int"]','groupProximityDrone',9082),
(140,'list','["bytes","int"]','groupSentryGun',9083),
(141,'list','["bytes","int"]','groupSkill',9084),
(142,'list','["bytes","int"]','groupSolarSystem',9085),
(143,'list','["bytes","int"]','groupSun',9086),
(144,'list','["bytes","int"]','groupTorpedo',9087),
(145,'list','["bytes","int"]','groupVoucher',9088),
(146,'list','["bytes","int"]','locationAbstract',9089),
(147,'list','["bytes","int"]','locationCorporation',9090),
(148,'list','["bytes","int"]','locationUniverse',9091),
(149,'list','["bytes","int"]','maxDockingDistance',9092),
(150,'list','["bytes","int"]','maxStargateJumpingDistance',9093),
(151,'list','["bytes","int"]','minWarpDistance',9094),
(152,'list','["bytes","int"]','ownerMarket',9095),
(153,'list','["bytes","int"]','ownerStation',9096),
(154,'list','["bytes","int"]','ownerSystem',9097),
(155,'list','["bytes","int"]','ownerTypeCharacter',9098),
(156,'list','["bytes","int"]','ownerTypeFaction',9099),
(157,'list','["bytes","int"]','rangeConstellation',9100),
(158,'list','["bytes","int"]','rangeRegion',9101),
(159,'list','["bytes","int"]','rangeSolarSystem',9102),
(160,'list','["bytes","int"]','rangeStation',9103),
(161,'list','["bytes","int"]','rentalPeriodOffice',9104),
(162,'list','["bytes","int"]','timeframeDay',9105),
(163,'list','["bytes","int"]','timeframeDay5',9106),
(164,'list','["bytes","int"]','timeframeMonth',9107),
(165,'list','["bytes","int"]','timeframeYear',9108),
(166,'list','["bytes","int"]','typeBasicFactoryOperation',9109),
(167,'list','["bytes","int"]','typeBookmarkVoucher',9110),
(168,'list','["bytes","int"]','typeCharacter',9111),
(169,'list','["bytes","int"]','typeCompanyShares',9112),
(170,'list','["bytes","int"]','typeConstellation',9113),
(171,'list','["bytes","int"]','typeCorporation',9114),
(172,'list','["bytes","int"]','typeCredits',9115),
(173,'list','["bytes","int"]','typeFactory',9116),
(174,'list','["bytes","int"]','typeFactoryFolder',9117),
(175,'list','["bytes","int"]','typeOfficeFolder',9118),
(176,'list','["bytes","int"]','typePlayahKill',9119),
(177,'list','["bytes","int"]','typeRegion',9120),
(178,'list','["bytes","int"]','typeShip',9121),
(179,'list','["bytes","int"]','typeSolarSystem',9122),
(180,'list','["bytes","int"]','unitGroupID',9123),
(181,'list','["bytes","int"]','unitInverseAbsolutePercent',9124),
(182,'list','["bytes","int"]','unitInversedModifierPercent',9125),
(183,'list','["bytes","int"]','unitMilliseconds',9126),
(184,'list','["bytes","int"]','unitModifierPercent',9127),
(185,'list','["bytes","int"]','unitPercentage',9128),
(186,'list','["bytes","int"]','unitSizeclass',9129),
(187,'list','["bytes","int"]','unitTypeID',9130),
(188,'list','["bytes","int"]','voteCEO',9131),
(189,'list','["bytes","int"]','voteGeneral',9132),
(190,'list','["bytes","int"]','voteKickMember',9133),
(191,'list','["bytes","int"]','voteShares',9134),
(192,'list','["bytes","int"]','voteWar',9135);
CREATE UNIQUE INDEX "pg_game_constants_0" ON "game_constants"("constantID");
CREATE  INDEX "pg_game_constants_1" ON "game_constants"("constantID");
-- Native Destiny catalog mappings and navigation distances.
UPDATE game_constants SET "constantValue"=5 WHERE "constantID"='categoryAccessories';
UPDATE game_constants SET "constantValue"=9 WHERE "constantID"='categoryBlueprint';
UPDATE game_constants SET "constantValue"=2 WHERE "constantID"='categoryCelestial';
UPDATE game_constants SET "constantValue"=8 WHERE "constantID"='categoryCharge';
UPDATE game_constants SET "constantValue"=11 WHERE "constantID"='categoryEntity';
UPDATE game_constants SET "constantValue"=7 WHERE "constantID"='categoryModule';
UPDATE game_constants SET "constantValue"=6 WHERE "constantID"='categoryShip';
UPDATE game_constants SET "constantValue"=3 WHERE "constantID"='categoryStation';
UPDATE game_constants SET "constantValue"=10 WHERE "constantID"='categoryTrading';
UPDATE game_constants SET "constantValue"=10000 WHERE "constantID"='dgmTauConstant';
UPDATE game_constants SET "constantValue"=1025 WHERE "constantID"='groupAmmo';
UPDATE game_constants SET "constantValue"=1017 WHERE "constantID"='groupArmor';
UPDATE game_constants SET "constantValue"=1029 WHERE "constantID"='groupAsteroid';
UPDATE game_constants SET "constantValue"=9056 WHERE "constantID"='groupAsteroidBelt';
UPDATE game_constants SET "constantValue"=27 WHERE "constantID"='groupBattleship';
UPDATE game_constants SET "constantValue"=9058 WHERE "constantID"='groupBiomass';
UPDATE game_constants SET "constantValue"=1020 WHERE "constantID"='groupCapacitor';
UPDATE game_constants SET "constantValue"=1020 WHERE "constantID"='groupCapacitorBooster';
UPDATE game_constants SET "constantValue"=29 WHERE "constantID"='groupCapsule';
UPDATE game_constants SET "constantValue"=9060 WHERE "constantID"='groupCargoContainer';
UPDATE game_constants SET "constantValue"=1 WHERE "constantID"='groupCharacter';
UPDATE game_constants SET "constantValue"=9061 WHERE "constantID"='groupCloud';
UPDATE game_constants SET "constantValue"=100 WHERE "constantID"='groupCombatDrone';
UPDATE game_constants SET "constantValue"=1022 WHERE "constantID"='groupComputer';
UPDATE game_constants SET "constantValue"=9062 WHERE "constantID"='groupCorporation';
UPDATE game_constants SET "constantValue"=26 WHERE "constantID"='groupCruiser';
UPDATE game_constants SET "constantValue"=9064 WHERE "constantID"='groupDroneLauncher';
UPDATE game_constants SET "constantValue"=1010 WHERE "constantID"='groupEnergyWeapon';
UPDATE game_constants SET "constantValue"=1011 WHERE "constantID"='groupHybridWeapon';
UPDATE game_constants SET "constantValue"=28 WHERE "constantID"='groupIndustrial';
UPDATE game_constants SET "constantValue"=9068 WHERE "constantID"='groupLargeCollidableObject';
UPDATE game_constants SET "constantValue"=1027 WHERE "constantID"='groupMine';
UPDATE game_constants SET "constantValue"=1028 WHERE "constantID"='groupMineral';
UPDATE game_constants SET "constantValue"=101 WHERE "constantID"='groupMiningDrone';
UPDATE game_constants SET "constantValue"=1013 WHERE "constantID"='groupMiningLaser';
UPDATE game_constants SET "constantValue"=1026 WHERE "constantID"='groupMissile';
UPDATE game_constants SET "constantValue"=1014 WHERE "constantID"='groupMissileLauncher';
UPDATE game_constants SET "constantValue"=9074 WHERE "constantID"='groupMoney';
UPDATE game_constants SET "constantValue"=9075 WHERE "constantID"='groupMoon';
UPDATE game_constants SET "constantValue"=9076 WHERE "constantID"='groupPirateDrone';
UPDATE game_constants SET "constantValue"=7 WHERE "constantID"='groupPlanet';
UPDATE game_constants SET "constantValue"=9078 WHERE "constantID"='groupPoliceDrone';
UPDATE game_constants SET "constantValue"=1019 WHERE "constantID"='groupPowerCore';
UPDATE game_constants SET "constantValue"=1012 WHERE "constantID"='groupProjectileWeapon';
UPDATE game_constants SET "constantValue"=1021 WHERE "constantID"='groupPropulsion';
UPDATE game_constants SET "constantValue"=9081 WHERE "constantID"='groupProtectiveSentryGun';
UPDATE game_constants SET "constantValue"=9082 WHERE "constantID"='groupProximityDrone';
UPDATE game_constants SET "constantValue"=9083 WHERE "constantID"='groupSentryGun';
UPDATE game_constants SET "constantValue"=1016 WHERE "constantID"='groupShield';
UPDATE game_constants SET "constantValue"=1000 WHERE "constantID"='groupSkill';
UPDATE game_constants SET "constantValue"=9085 WHERE "constantID"='groupSolarSystem';
UPDATE game_constants SET "constantValue"=10 WHERE "constantID"='groupStargate';
UPDATE game_constants SET "constantValue"=15 WHERE "constantID"='groupStation';
UPDATE game_constants SET "constantValue"=9086 WHERE "constantID"='groupSun';
UPDATE game_constants SET "constantValue"=9087 WHERE "constantID"='groupTorpedo';
UPDATE game_constants SET "constantValue"=9088 WHERE "constantID"='groupVoucher';
UPDATE game_constants SET "constantValue"=2500 WHERE "constantID"='maxDockingDistance';
UPDATE game_constants SET "constantValue"=2500 WHERE "constantID"='maxStargateJumpingDistance';
UPDATE game_constants SET "constantValue"=150000 WHERE "constantID"='minWarpDistance';
COMMIT;
