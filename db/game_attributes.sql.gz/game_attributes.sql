-- Gemini 665 PostgreSQL table: game_attributes
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_attributes" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "attributeID" BIGINT,
  "attributeName" TEXT,
  "description" TEXT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_attributes" ("_ordinal","_shape","_kinds","attributeID","attributeName","description") VALUES
(0,'list','["int","bytes","bytes"]',1,'Charisma',''),
(1,'list','["int","bytes","bytes"]',2,'Intelligence',''),
(2,'list','["int","bytes","bytes"]',3,'Memory',''),
(3,'list','["int","bytes","bytes"]',4,'Perception',''),
(4,'list','["int","bytes","bytes"]',5,'Willpower','');
CREATE  INDEX "pg_game_attributes_0" ON "game_attributes"("attributeID");
COMMIT;
