-- Gemini 665 PostgreSQL table: game_agent_types
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_agent_types" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "agentTypeID" BIGINT,
  "agentTypeName" TEXT,
  "description" TEXT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_agent_types" ("_ordinal","_shape","_kinds","agentTypeID","agentTypeName","description") VALUES
(0,'list','["int","bytes","bytes"]',1,'Agent','');
CREATE  INDEX "pg_game_agent_types_0" ON "game_agent_types"("agentTypeID");
COMMIT;
