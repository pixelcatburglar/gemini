-- Gemini 665 PostgreSQL table: game_shiptypes
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_shiptypes" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "shipTypeID" BIGINT,
  "weaponTypeID" TEXT,
  "miningTypeID" TEXT,
  "skillTypeID" TEXT,
  "powerCoreTypeID" BIGINT,
  "capacitorTypeID" BIGINT,
  "shieldTypeID" BIGINT,
  "propulsionTypeID" TEXT,
  "sensorTypeID" TEXT,
  "armorTypeID" BIGINT,
  "computerTypeID" BIGINT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_shiptypes" ("_ordinal","_shape","_kinds","shipTypeID","weaponTypeID","miningTypeID","skillTypeID","powerCoreTypeID","capacitorTypeID","shieldTypeID","propulsionTypeID","sensorTypeID","armorTypeID","computerTypeID") VALUES
(0,'list','["int","none","none","none","int","int","int","none","none","int","int"]',582,NULL,NULL,NULL,20087,20090,20073,NULL,NULL,20079,20109),
(1,'list','["int","none","none","none","int","int","int","none","none","int","int"]',583,NULL,NULL,NULL,20087,20090,20073,NULL,NULL,20079,20109),
(2,'list','["int","none","none","none","int","int","int","none","none","int","int"]',584,NULL,NULL,NULL,20087,20090,20073,NULL,NULL,20079,20109),
(3,'list','["int","none","none","none","int","int","int","none","none","int","int"]',585,NULL,NULL,NULL,20087,20090,20073,NULL,NULL,20079,20109),
(4,'list','["int","none","none","none","int","int","int","none","none","int","int"]',586,NULL,NULL,NULL,20087,20090,20073,NULL,NULL,20079,20109),
(5,'list','["int","none","none","none","int","int","int","none","none","int","int"]',587,NULL,NULL,NULL,20087,20090,20073,NULL,NULL,20079,20109),
(6,'list','["int","none","none","none","int","int","int","none","none","int","int"]',588,NULL,NULL,NULL,20087,20090,20073,NULL,NULL,20079,20109),
(7,'list','["int","none","none","none","int","int","int","none","none","int","int"]',589,NULL,NULL,NULL,20087,20090,20073,NULL,NULL,20079,20109),
(8,'list','["int","none","none","none","int","int","int","none","none","int","int"]',590,NULL,NULL,NULL,20087,20090,20073,NULL,NULL,20079,20109),
(9,'list','["int","none","none","none","int","int","int","none","none","int","int"]',591,NULL,NULL,NULL,20087,20090,20073,NULL,NULL,20079,20109),
(10,'list','["int","none","none","none","int","int","int","none","none","int","int"]',592,NULL,NULL,NULL,20087,20090,20073,NULL,NULL,20079,20109),
(11,'list','["int","none","none","none","int","int","int","none","none","int","int"]',593,NULL,NULL,NULL,20087,20090,20073,NULL,NULL,20079,20109),
(12,'list','["int","none","none","none","int","int","int","none","none","int","int"]',594,NULL,NULL,NULL,20087,20090,20073,NULL,NULL,20079,20109),
(13,'list','["int","none","none","none","int","int","int","none","none","int","int"]',620,NULL,NULL,NULL,20088,20090,20074,NULL,NULL,20080,20110),
(14,'list','["int","none","none","none","int","int","int","none","none","int","int"]',621,NULL,NULL,NULL,20088,20090,20074,NULL,NULL,20080,20110),
(15,'list','["int","none","none","none","int","int","int","none","none","int","int"]',622,NULL,NULL,NULL,20088,20090,20074,NULL,NULL,20080,20110),
(16,'list','["int","none","none","none","int","int","int","none","none","int","int"]',623,NULL,NULL,NULL,20088,20090,20074,NULL,NULL,20080,20110),
(17,'list','["int","none","none","none","int","int","int","none","none","int","int"]',624,NULL,NULL,NULL,20088,20090,20074,NULL,NULL,20080,20110),
(18,'list','["int","none","none","none","int","int","int","none","none","int","int"]',625,NULL,NULL,NULL,20088,20090,20074,NULL,NULL,20080,20110),
(19,'list','["int","none","none","none","int","int","int","none","none","int","int"]',626,NULL,NULL,NULL,20088,20090,20074,NULL,NULL,20080,20110),
(20,'list','["int","none","none","none","int","int","int","none","none","int","int"]',627,NULL,NULL,NULL,20088,20090,20074,NULL,NULL,20080,20110),
(21,'list','["int","none","none","none","int","int","int","none","none","int","int"]',638,NULL,NULL,NULL,20089,20090,20075,NULL,NULL,20081,20111),
(22,'list','["int","none","none","none","int","int","int","none","none","int","int"]',639,NULL,NULL,NULL,20089,20090,20075,NULL,NULL,20081,20111),
(23,'list','["int","none","none","none","int","int","int","none","none","int","int"]',640,NULL,NULL,NULL,20089,20090,20075,NULL,NULL,20081,20111),
(24,'list','["int","none","none","none","int","int","int","none","none","int","int"]',641,NULL,NULL,NULL,20089,20090,20075,NULL,NULL,20081,20111),
(25,'list','["int","none","none","none","int","int","int","none","none","int","int"]',648,NULL,NULL,NULL,20087,20090,20073,NULL,NULL,20079,20109),
(26,'list','["int","none","none","none","int","int","int","none","none","int","int"]',649,NULL,NULL,NULL,20087,20090,20073,NULL,NULL,20079,20109),
(27,'list','["int","none","none","none","int","int","int","none","none","int","int"]',650,NULL,NULL,NULL,20087,20090,20073,NULL,NULL,20079,20109),
(28,'list','["int","none","none","none","int","int","int","none","none","int","int"]',651,NULL,NULL,NULL,20087,20090,20073,NULL,NULL,20079,20109);
CREATE  INDEX "pg_game_shiptypes_0" ON "game_shiptypes"("shipTypeID");
COMMIT;
