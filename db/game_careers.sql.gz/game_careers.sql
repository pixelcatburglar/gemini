-- Gemini 665 PostgreSQL table: game_careers
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_careers" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "careerID" BIGINT,
  "careerName" TEXT,
  "raceID" BIGINT,
  "schoolID" BIGINT,
  "description" TEXT,
  "preAttributeID" TEXT,
  "preAttributeValue" TEXT,
  "preSchoolID" TEXT,
  "preSchoolTypeID" TEXT,
  "postAgentTypeID" BIGINT,
  "postBonusTypeID" TEXT,
  "graphicID" TEXT,
  "preSkillTypeID1" TEXT,
  "preSkillTypeID2" TEXT,
  "preSkillTypeID3" TEXT,
  "postSkillTypeID1" BIGINT,
  "postSkillTypeID2" BIGINT,
  "postSkillTypeID3" BIGINT,
  "postSkillTypeID4" BIGINT,
  "postSkillTypeID5" BIGINT,
  "postSkillTypeID6" BIGINT,
  "postSkillTypeID7" BIGINT,
  "postSkillTypeID8" BIGINT,
  "postSkillTypeID9" BIGINT,
  "postSkillTypeID10" BIGINT,
  "preDeteis" BIGINT,
  "preCivire" BIGINT,
  "preSebiestor" BIGINT,
  "preBrutor" BIGINT,
  "preAmarr" BIGINT,
  "preNiKunni" BIGINT,
  "preGallente" BIGINT,
  "preIntaki" BIGINT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_careers" ("_ordinal","_shape","_kinds","careerID","careerName","raceID","schoolID","description","preAttributeID","preAttributeValue","preSchoolID","preSchoolTypeID","postAgentTypeID","postBonusTypeID","graphicID","preSkillTypeID1","preSkillTypeID2","preSkillTypeID3","postSkillTypeID1","postSkillTypeID2","postSkillTypeID3","postSkillTypeID4","postSkillTypeID5","postSkillTypeID6","postSkillTypeID7","postSkillTypeID8","postSkillTypeID9","postSkillTypeID10","preDeteis","preCivire","preSebiestor","preBrutor","preAmarr","preNiKunni","preGallente","preIntaki") VALUES
(0,'list','["int","bytes","int","int","bytes","none","none","none","none","int","none","none","none","none","none","int","int","int","int","int","int","int","int","int","int","int","int","int","int","int","int","int","int"]',1,'Caldari Career',1,1,'',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,1100,1101,1102,1103,1104,1105,1106,1107,1108,1109,1,1,1,1,1,1,1,1),
(1,'list','["int","bytes","int","int","bytes","none","none","none","none","int","none","none","none","none","none","int","int","int","int","int","int","int","int","int","int","int","int","int","int","int","int","int","int"]',2,'Minmatar Career',2,2,'',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,1110,1111,1112,1113,1114,1115,1116,1117,1118,1119,1,1,1,1,1,1,1,1),
(2,'list','["int","bytes","int","int","bytes","none","none","none","none","int","none","none","none","none","none","int","int","int","int","int","int","int","int","int","int","int","int","int","int","int","int","int","int"]',4,'Amarr Career',4,4,'',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,1120,1121,1122,1123,1124,1125,1126,1127,1128,1129,1,1,1,1,1,1,1,1),
(3,'list','["int","bytes","int","int","bytes","none","none","none","none","int","none","none","none","none","none","int","int","int","int","int","int","int","int","int","int","int","int","int","int","int","int","int","int"]',8,'Gallente Career',8,8,'',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,1130,1131,1132,1133,1134,1135,1136,1137,1138,1139,1,1,1,1,1,1,1,1);
CREATE  INDEX "pg_game_careers_0" ON "game_careers"("careerID");
COMMIT;
