-- Gemini 665 PostgreSQL table: character_location
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "character_location" (
  "characterID" BIGINT,
  "stationID" BIGINT,
  "solarSystemID" BIGINT NOT NULL,
  "constellationID" BIGINT NOT NULL,
  "regionID" BIGINT NOT NULL,
  "shipID" BIGINT,
  PRIMARY KEY ("characterID")
);
INSERT INTO "character_location" ("characterID","stationID","solarSystemID","constellationID","regionID","shipID") VALUES
(90000001,64000055,30001381,20000202,10000020,NULL),
(90000002,64000055,30001381,20000202,10000020,NULL),
(90000003,64000055,30001381,20000202,10000020,NULL);
ALTER TABLE "character_location" ADD CONSTRAINT "fk_character_location_0" FOREIGN KEY ("characterID") REFERENCES "characters" ("characterID") ON UPDATE NO ACTION ON DELETE NO ACTION;
COMMIT;
