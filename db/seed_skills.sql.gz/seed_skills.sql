-- Gemini 665 PostgreSQL table: seed_skills
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "seed_skills" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "ownerID" BIGINT,
  "typeID" BIGINT,
  "level" BIGINT,
  "skillPoints" BIGINT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "seed_skills" ("_ordinal","_shape","_kinds","ownerID","typeID","level","skillPoints") VALUES
(0,'dict','["int","int","int","int"]',90000001,1140,0,0),
(1,'dict','["int","int","int","int"]',90000001,1141,0,0);
CREATE  INDEX "pg_seed_skills_0" ON "seed_skills"("ownerID");
COMMIT;
