-- Gemini 665 PostgreSQL table: game_school_types
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_school_types" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "schoolTypeID" BIGINT,
  "schoolTypeName" TEXT,
  "description" TEXT,
  "preSchoolTypeID" TEXT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_school_types" ("_ordinal","_shape","_kinds","schoolTypeID","schoolTypeName","description","preSchoolTypeID") VALUES
(0,'list','["int","bytes","bytes","none"]',1,'School','',NULL);
CREATE  INDEX "pg_game_school_types_0" ON "game_school_types"("schoolTypeID");
COMMIT;
