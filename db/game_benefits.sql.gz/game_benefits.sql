-- Gemini 665 PostgreSQL table: game_benefits
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_benefits" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "benefitID" BIGINT,
  "physicalTraidID" BIGINT,
  "benefitName" TEXT,
  "description" TEXT,
  "numPoints" BIGINT,
  "points" BIGINT,
  "maxTimes" BIGINT,
  "preAttributeID" TEXT,
  "preAttributeValue" TEXT,
  "postAttributeID" TEXT,
  "postAttributeValue" TEXT,
  "postBonusTypeID" TEXT,
  "costDeteis" BIGINT,
  "costCivire" BIGINT,
  "costSebiestor" BIGINT,
  "costBrutor" BIGINT,
  "costAmarr" BIGINT,
  "costNiKunni" BIGINT,
  "costGallente" BIGINT,
  "costIntaki" BIGINT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_benefits" ("_ordinal","_shape","_kinds","benefitID","physicalTraidID","benefitName","description","numPoints","points","maxTimes","preAttributeID","preAttributeValue","postAttributeID","postAttributeValue","postBonusTypeID","costDeteis","costCivire","costSebiestor","costBrutor","costAmarr","costNiKunni","costGallente","costIntaki") VALUES
(0,'list','["int","int","bytes","bytes","int","int","int","none","none","none","none","none","int","int","int","int","int","int","int","int"]',1,1,'Benefit','',1,1,1,NULL,NULL,NULL,NULL,NULL,1,1,1,1,1,1,1,1);
CREATE  INDEX "pg_game_benefits_0" ON "game_benefits"("benefitID");
COMMIT;
