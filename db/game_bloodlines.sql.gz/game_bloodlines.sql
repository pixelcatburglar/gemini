-- Gemini 665 PostgreSQL table: game_bloodlines
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_bloodlines" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "bloodlineID" BIGINT,
  "bloodlineName" TEXT,
  "raceID" BIGINT,
  "description" TEXT,
  "maleDescription" TEXT,
  "femaleDescription" TEXT,
  "shipTypeID" TEXT,
  "corporationID" TEXT,
  "bonusTypeID" TEXT,
  "graphicID" TEXT,
  "charisma" BIGINT,
  "intelligence" BIGINT,
  "memory" BIGINT,
  "perception" BIGINT,
  "willpower" BIGINT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_bloodlines" ("_ordinal","_shape","_kinds","bloodlineID","bloodlineName","raceID","description","maleDescription","femaleDescription","shipTypeID","corporationID","bonusTypeID","graphicID","charisma","intelligence","memory","perception","willpower") VALUES
(0,'list','["int","bytes","int","bytes","bytes","bytes","none","none","none","none","int","int","int","int","int"]',1,'Deteis',1,'','','',NULL,NULL,NULL,NULL,3,6,5,3,3),
(1,'list','["int","bytes","int","bytes","bytes","bytes","none","none","none","none","int","int","int","int","int"]',2,'Civire',1,'','','',NULL,NULL,NULL,NULL,3,5,4,5,3),
(2,'list','["int","bytes","int","bytes","bytes","bytes","none","none","none","none","int","int","int","int","int"]',3,'Sebiestor',2,'','','',NULL,NULL,NULL,NULL,3,6,4,4,3),
(3,'list','["int","bytes","int","bytes","bytes","bytes","none","none","none","none","int","int","int","int","int"]',4,'Brutor',2,'','','',NULL,NULL,NULL,NULL,4,3,3,5,5),
(4,'list','["int","bytes","int","bytes","bytes","bytes","none","none","none","none","int","int","int","int","int"]',5,'Amarr',4,'','','',NULL,NULL,NULL,NULL,3,5,5,3,4),
(5,'list','["int","bytes","int","bytes","bytes","bytes","none","none","none","none","int","int","int","int","int"]',6,'Ni-Kunni',4,'','','',NULL,NULL,NULL,NULL,5,5,3,4,3),
(6,'list','["int","bytes","int","bytes","bytes","bytes","none","none","none","none","int","int","int","int","int"]',7,'Gallente',8,'','','',NULL,NULL,NULL,NULL,5,4,4,4,3),
(7,'list','["int","bytes","int","bytes","bytes","bytes","none","none","none","none","int","int","int","int","int"]',8,'Intaki',8,'','','',NULL,NULL,NULL,NULL,5,5,5,3,2);
CREATE  INDEX "pg_game_bloodlines_0" ON "game_bloodlines"("bloodlineID");
COMMIT;
