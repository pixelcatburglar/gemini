-- Gemini 665 PostgreSQL table: character_appearance
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "character_appearance" (
  "characterID" BIGINT NOT NULL,
  "parameterName" TEXT NOT NULL,
  "parameterValue" TEXT NOT NULL,
  PRIMARY KEY ("characterID","parameterName")
);
INSERT INTO "character_appearance" ("characterID","parameterName","parameterValue") VALUES
(90000002,'eyebrows','12'),
(90000002,'eyes','Deep brown'),
(90000002,'deco','8'),
(90000002,'lipstick','7'),
(90000002,'makeup','11'),
(90000002,'hair','10'),
(90000002,'Lights','Red alert'),
(90000002,'camPos','6.43766592969e-032,1.37950168928e-032,0.0'),
(90000002,'costume','20'),
(90000002,'Background','tunnel'),
(90000002,'skin','7'),
(90000002,'headRotation','0.0,0.0,-0.035554587841'),
(90000002,'eyeRotation','0.0,0.0,0.0'),
(90000003,'eyebrows','4'),
(90000003,'eyes','Stinging greyblue'),
(90000003,'deco','8'),
(90000003,'lipstick','Lead'),
(90000003,'makeup','1'),
(90000003,'hair','Luminant'),
(90000003,'Lights','Drama sidelights'),
(90000003,'camPos','7.39885589164e-043,3.97968763868e-043,0.0'),
(90000003,'costume','1'),
(90000003,'Background','Rabbitskull'),
(90000003,'skin','7'),
(90000003,'headRotation','0.0,0.0,0.0161650292575'),
(90000003,'eyeRotation','0.0,0.0,0.0');
ALTER TABLE "character_appearance" ADD CONSTRAINT "fk_character_appearance_0" FOREIGN KEY ("characterID") REFERENCES "characters" ("characterID") ON UPDATE NO ACTION ON DELETE NO ACTION;
COMMIT;
