-- Gemini 665 PostgreSQL table: seed_inventory
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "seed_inventory" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "itemID" BIGINT,
  "ownerID" BIGINT,
  "locationID" BIGINT,
  "typeID" BIGINT,
  "flag" BIGINT,
  "quantity" BIGINT,
  "singleton" BIGINT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "seed_inventory" ("_ordinal","_shape","_kinds","itemID","ownerID","locationID","typeID","flag","quantity","singleton") VALUES
(0,'dict','["int","int","int","int","int","int","int"]',91000001,90000001,64000055,587,4,1,1);
CREATE  INDEX "pg_seed_inventory_0" ON "seed_inventory"("itemID");
COMMIT;
