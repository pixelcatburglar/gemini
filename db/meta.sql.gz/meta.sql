-- Gemini 665 PostgreSQL table: meta
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "meta" (
  "key" TEXT,
  "value" TEXT NOT NULL,
  PRIMARY KEY ("key")
);
INSERT INTO meta(key,value) VALUES('builder','tools/build_map_db.py');
INSERT INTO meta(key,value) VALUES('bulk_version','31');
INSERT INTO meta(key,value) VALUES('note_leaves','celestials/stargates/stations have IDs only -- no names or coordinates exist for them in the source or anywhere in the install');
INSERT INTO meta(key,value) VALUES('postgres_schema_version','1');
INSERT INTO meta(key,value) VALUES('provenance','Real CCP data: written by ui/shared/maps/map.py from the live 2002 beta server, not shipped content. No second copy exists.');
INSERT INTO meta(key,value) VALUES('schema_version','4');
INSERT INTO meta(key,value) VALUES('server_reference_provenance','Native Rust import of the reconstructed Gemini 665 POC catalog; original map tables preserved. Scene names/layout and catalog additions are reconstructed, not a recovered full CCP content database.');
INSERT INTO meta(key,value) VALUES('server_reference_version','1');
INSERT INTO meta(key,value) VALUES('source','cache/Map/cachefile.blue');
INSERT INTO meta(key,value) VALUES('source_bytes','1467274');
INSERT INTO meta(key,value) VALUES('source_mtime','1037490374');
INSERT INTO meta(key,value) VALUES('source_sha256','0585bf90521fbe395f18d521a44177173b0c1fd4980371879d02752baaf3c62d');
INSERT INTO meta(key,value) VALUES('storage_backend','PostgreSQL');
COMMIT;
