-- Gemini 665 PostgreSQL table: characters
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "characters" (
  "characterID" BIGINT,
  "characterName" TEXT NOT NULL,
  "bloodlineID" BIGINT,
  "raceID" BIGINT,
  "gender" BIGINT,
  "security" DOUBLE PRECISION,
  "corporationID" BIGINT,
  "typeID" BIGINT,
  "charisma" BIGINT,
  "intelligence" BIGINT,
  "memory" BIGINT,
  "perception" BIGINT,
  "willpower" BIGINT,
  "accountID" BIGINT,
  PRIMARY KEY ("characterID")
);
INSERT INTO "characters" ("characterID","characterName","bloodlineID","raceID","gender","security","corporationID","typeID","charisma","intelligence","memory","perception","willpower","accountID") VALUES
(90000001,'Test Pilot',1,1,1,0,1000001,1373,3,6,5,3,3,NULL),
(90000002,'Sophia',1,1,0,0,1000001,1373,4,7,6,4,4,NULL),
(90000003,'Emily',1,1,0,0,1000001,1373,4,7,6,4,4,NULL);
CREATE  INDEX "pg_characters_0" ON "characters"("accountID");
ALTER TABLE "characters" ADD CONSTRAINT "fk_characters_0" FOREIGN KEY ("accountID") REFERENCES "accounts" ("accountID") ON UPDATE NO ACTION ON DELETE NO ACTION;
COMMIT;
