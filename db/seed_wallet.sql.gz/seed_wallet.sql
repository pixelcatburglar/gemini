-- Gemini 665 PostgreSQL table: seed_wallet
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "seed_wallet" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "ownerID" BIGINT,
  "balance" DOUBLE PRECISION,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "seed_wallet" ("_ordinal","_shape","_kinds","ownerID","balance") VALUES
(0,'dict','["int","float"]',90000001,500000000000);
CREATE  INDEX "pg_seed_wallet_0" ON "seed_wallet"("ownerID");
COMMIT;
