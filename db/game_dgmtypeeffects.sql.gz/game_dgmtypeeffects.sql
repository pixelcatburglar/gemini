-- Gemini 665 PostgreSQL table: game_dgmtypeeffects
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_dgmtypeeffects" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "typeID" TEXT,
  "effectID" TEXT,
  "isDefault" TEXT,
  PRIMARY KEY ("_ordinal")
);
CREATE  INDEX "pg_game_dgmtypeeffects_0" ON "game_dgmtypeeffects"("typeID");
COMMIT;
