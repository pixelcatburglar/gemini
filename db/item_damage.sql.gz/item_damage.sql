BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE IF NOT EXISTS item_damage (
 "shipID" BIGINT NOT NULL REFERENCES inventory("itemID") ON DELETE CASCADE,
 "itemID" BIGINT NOT NULL, damage DOUBLE PRECISION NOT NULL DEFAULT 0
 CHECK (damage >= 0 AND damage < 'Infinity'::float8), PRIMARY KEY("shipID","itemID"));
COMMIT;
