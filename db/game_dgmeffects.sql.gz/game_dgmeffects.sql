-- Gemini 665 PostgreSQL table: game_dgmeffects
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_dgmeffects" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "effectID" TEXT,
  "effectName" TEXT,
  "description" TEXT,
  "published" TEXT,
  PRIMARY KEY ("_ordinal")
);
CREATE  INDEX "pg_game_dgmeffects_0" ON "game_dgmeffects"("effectID");
COMMIT;
