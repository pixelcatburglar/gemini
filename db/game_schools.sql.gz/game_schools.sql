-- Gemini 665 PostgreSQL table: game_schools
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_schools" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "schoolID" BIGINT,
  "schoolName" TEXT,
  "schoolTypeID" BIGINT,
  "raceID" BIGINT,
  "description" TEXT,
  "preBenefitID" TEXT,
  "preAncestry" TEXT,
  "term" BIGINT,
  "graphicID" TEXT,
  "postAttributeID" TEXT,
  "postAttributeValue" TEXT,
  "postAgentTypeID" TEXT,
  "postBonusTypeID" TEXT,
  "postSkillTypeID1" TEXT,
  "postSkillTypeID2" TEXT,
  "postSkillTypeID3" TEXT,
  "postSkillTypeID4" TEXT,
  "postSkillTypeID5" TEXT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_schools" ("_ordinal","_shape","_kinds","schoolID","schoolName","schoolTypeID","raceID","description","preBenefitID","preAncestry","term","graphicID","postAttributeID","postAttributeValue","postAgentTypeID","postBonusTypeID","postSkillTypeID1","postSkillTypeID2","postSkillTypeID3","postSkillTypeID4","postSkillTypeID5") VALUES
(0,'list','["int","bytes","int","int","bytes","none","none","int","none","none","none","none","none","none","none","none","none","none"]',1,'Caldari School',1,1,'',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1,'list','["int","bytes","int","int","bytes","none","none","int","none","none","none","none","none","none","none","none","none","none"]',2,'Minmatar School',1,2,'',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(2,'list','["int","bytes","int","int","bytes","none","none","int","none","none","none","none","none","none","none","none","none","none"]',4,'Amarr School',1,4,'',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(3,'list','["int","bytes","int","int","bytes","none","none","int","none","none","none","none","none","none","none","none","none","none"]',8,'Gallente School',1,8,'',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
CREATE  INDEX "pg_game_schools_0" ON "game_schools"("schoolID");
COMMIT;
