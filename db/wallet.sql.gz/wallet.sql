-- Gemini 665 PostgreSQL table: wallet
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "wallet" (
  "ownerID" BIGINT,
  "balance" DOUBLE PRECISION NOT NULL DEFAULT 0.0,
  PRIMARY KEY ("ownerID")
);
INSERT INTO "wallet" ("ownerID","balance") VALUES
(90000001,500000000000),
(90000002,499999498925),
(90000003,499999450445);
COMMIT;
