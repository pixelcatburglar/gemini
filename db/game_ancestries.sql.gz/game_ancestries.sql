-- Gemini 665 PostgreSQL table: game_ancestries
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_ancestries" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "ancestryID" BIGINT,
  "ancestryName" TEXT,
  "bloodlineID" BIGINT,
  "description" TEXT,
  "graphicID" TEXT,
  "postBenefitID1" BIGINT,
  "postBenefitValue1" BIGINT,
  "postBenefitID2" BIGINT,
  "postBenefitValue2" BIGINT,
  "allowSchoolTypeID" BIGINT,
  "postPerception" BIGINT,
  "postWillpower" BIGINT,
  "postCharisma" BIGINT,
  "postMemory" BIGINT,
  "postIntelligence" BIGINT,
  "banCareerID" TEXT,
  "allowCareerID" TEXT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_ancestries" ("_ordinal","_shape","_kinds","ancestryID","ancestryName","bloodlineID","description","graphicID","postBenefitID1","postBenefitValue1","postBenefitID2","postBenefitValue2","allowSchoolTypeID","postPerception","postWillpower","postCharisma","postMemory","postIntelligence","banCareerID","allowCareerID") VALUES
(0,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',1,'Deteis Ancestry 1',1,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(1,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',2,'Deteis Ancestry 2',1,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(2,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',3,'Deteis Ancestry 3',1,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(3,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',4,'Civire Ancestry 1',2,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(4,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',5,'Civire Ancestry 2',2,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(5,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',6,'Civire Ancestry 3',2,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(6,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',7,'Sebiestor Ancestry 1',3,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(7,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',8,'Sebiestor Ancestry 2',3,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(8,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',9,'Sebiestor Ancestry 3',3,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(9,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',10,'Brutor Ancestry 1',4,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(10,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',11,'Brutor Ancestry 2',4,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(11,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',12,'Brutor Ancestry 3',4,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(12,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',13,'Amarr Ancestry 1',5,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(13,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',14,'Amarr Ancestry 2',5,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(14,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',15,'Amarr Ancestry 3',5,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(15,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',16,'Ni-Kunni Ancestry 1',6,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(16,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',17,'Ni-Kunni Ancestry 2',6,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(17,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',18,'Ni-Kunni Ancestry 3',6,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(18,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',19,'Gallente Ancestry 1',7,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(19,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',20,'Gallente Ancestry 2',7,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(20,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',21,'Gallente Ancestry 3',7,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(21,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',22,'Intaki Ancestry 1',8,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(22,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',23,'Intaki Ancestry 2',8,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL),
(23,'list','["int","bytes","int","bytes","none","int","int","int","int","int","int","int","int","int","int","none","none"]',24,'Intaki Ancestry 3',8,'',NULL,1,-1,1,1,1,0,0,0,0,0,NULL,NULL);
CREATE  INDEX "pg_game_ancestries_0" ON "game_ancestries"("ancestryID");
COMMIT;
