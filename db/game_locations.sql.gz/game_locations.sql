-- Gemini 665 PostgreSQL table: game_locations
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_locations" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "locationID" BIGINT,
  "locationName" TEXT,
  "x" DOUBLE PRECISION,
  "y" DOUBLE PRECISION,
  "z" DOUBLE PRECISION,
  "solarSystemID" BIGINT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_locations" ("_ordinal","_shape","_kinds","locationID","locationName","x","y","z","solarSystemID") VALUES
(0,'list','["int","bytes","float","float","float","none"]',10000020,'Gemini',54974367812301790,-51893254265458900,47973868976116940,NULL),
(1,'list','["int","bytes","float","float","float","none"]',20000202,'Erquenondë',52924902015803176,-48483420440494860,60708565667210910,NULL),
(2,'list','["int","bytes","float","float","float","int"]',30001381,'Flodinus',45802164105662480,-56887680733497580,72201644942583220,30001381),
(3,'list','["int","bytes","float","float","float","int"]',64000055,'Flodinus Station',45802164105662480,-56887680733497580,72201644942583220,30001381);
CREATE  INDEX "pg_game_locations_0" ON "game_locations"("locationID");
COMMIT;
