-- Gemini 665 PostgreSQL table: market_price_history
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "market_price_history" (
  "regionID" BIGINT NOT NULL,
  "typeID" BIGINT NOT NULL,
  "day" BIGINT NOT NULL,
  "lowPrice" DOUBLE PRECISION NOT NULL,
  "highPrice" DOUBLE PRECISION NOT NULL,
  "closePrice" DOUBLE PRECISION NOT NULL,
  "volume" BIGINT NOT NULL DEFAULT 0,
  "orders" BIGINT NOT NULL DEFAULT 0,
  PRIMARY KEY ("regionID","typeID","day")
);
INSERT INTO "market_price_history" ("regionID","typeID","day","lowPrice","highPrice","closePrice","volume","orders") VALUES
(10000020,651,20670,501075,501075,501075,2,2),
(10000020,20065,20670,48480,48480,48480,1,1);
COMMIT;
