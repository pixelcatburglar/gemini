-- Gemini 665 PostgreSQL table: game_owners
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_owners" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "ownerID" BIGINT,
  "ownerName" TEXT,
  "typeID" BIGINT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_owners" ("_ordinal","_shape","_kinds","ownerID","ownerName","typeID") VALUES
(0,'list','["int","bytes","int"]',90000001,'Test Pilot',1373),
(1,'list','["int","bytes","int"]',1000001,'Test Corporation',2),
(2,'list','["int","bytes","int"]',1000666,'Pirates',2);
CREATE  INDEX "pg_game_owners_0" ON "game_owners"("ownerID");
COMMIT;
