-- Gemini 665 PostgreSQL table: seed_characters
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "seed_characters" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "characterID" BIGINT,
  "accountID" TEXT,
  "characterName" TEXT,
  "bloodlineID" BIGINT,
  "raceID" BIGINT,
  "gender" BIGINT,
  "security" DOUBLE PRECISION,
  "corporationID" BIGINT,
  "typeID" BIGINT,
  "charisma" BIGINT,
  "intelligence" BIGINT,
  "memory" BIGINT,
  "perception" BIGINT,
  "willpower" BIGINT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "seed_characters" ("_ordinal","_shape","_kinds","characterID","accountID","characterName","bloodlineID","raceID","gender","security","corporationID","typeID","charisma","intelligence","memory","perception","willpower") VALUES
(0,'dict','["int","none","bytes","int","int","int","float","int","int","int","int","int","int","int"]',90000001,NULL,'Test Pilot',1,1,1,0,1000001,1373,3,6,5,3,3);
CREATE  INDEX "pg_seed_characters_0" ON "seed_characters"("characterID");
COMMIT;
