-- Gemini 665 PostgreSQL table: game_races
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_races" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "raceID" BIGINT,
  "raceName" TEXT,
  "description" TEXT,
  "graphicID" TEXT,
  "shortDescription" TEXT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_races" ("_ordinal","_shape","_kinds","raceID","raceName","description","graphicID","shortDescription") VALUES
(0,'list','["int","bytes","bytes","none","bytes"]',1,'Caldari','',NULL,''),
(1,'list','["int","bytes","bytes","none","bytes"]',2,'Minmatar','',NULL,''),
(2,'list','["int","bytes","bytes","none","bytes"]',4,'Amarr','',NULL,''),
(3,'list','["int","bytes","bytes","none","bytes"]',8,'Gallente','',NULL,'');
CREATE  INDEX "pg_game_races_0" ON "game_races"("raceID");
COMMIT;
