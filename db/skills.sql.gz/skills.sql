-- Gemini 665 PostgreSQL table: skills
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "skills" (
  "ownerID" BIGINT NOT NULL,
  "typeID" BIGINT NOT NULL,
  "level" BIGINT NOT NULL DEFAULT 0,
  "skillPoints" BIGINT NOT NULL DEFAULT 0,
  PRIMARY KEY ("ownerID","typeID")
);
INSERT INTO "skills" ("ownerID","typeID","level","skillPoints") VALUES
(90000001,1140,0,0),
(90000002,1140,0,0),
(90000003,1140,0,0),
(90000001,1141,0,0),
(90000002,1141,0,0),
(90000003,1141,0,0);
COMMIT;
