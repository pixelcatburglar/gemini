-- Gemini 665 PostgreSQL table: game_groups
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_groups" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "groupID" BIGINT,
  "categoryID" BIGINT,
  "groupName" TEXT,
  "description" TEXT,
  "published" BIGINT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_groups" ("_ordinal","_shape","_kinds","groupID","categoryID","groupName","description","published") VALUES
(0,'list','["int","int","bytes","bytes","int"]',25,6,'Frigate','',1),
(1,'list','["int","int","bytes","bytes","int"]',15,3,'Station','',1),
(2,'list','["int","int","bytes","bytes","int"]',7,2,'Planet','',1),
(3,'list','["int","int","bytes","bytes","int"]',1000,16,'Skill','',1),
(4,'list','["int","int","bytes","bytes","int"]',1001,4,'Ship Colour','',1),
(5,'list','["int","int","bytes","bytes","int"]',1050,11,'Pirate Frigate','',1),
(6,'list','["int","int","bytes","bytes","int"]',1010,7,'Energy Weapon','',1),
(7,'list','["int","int","bytes","bytes","int"]',1011,7,'Hybrid Weapon','',1),
(8,'list','["int","int","bytes","bytes","int"]',1012,7,'Projectile Weapon','',1),
(9,'list','["int","int","bytes","bytes","int"]',1013,7,'Mining Laser','',1),
(10,'list','["int","int","bytes","bytes","int"]',1014,7,'Missile Launcher','',1),
(11,'list','["int","int","bytes","bytes","int"]',1015,7,'Turret Accessory','',1),
(12,'list','["int","int","bytes","bytes","int"]',1016,7,'Shield System','',1),
(13,'list','["int","int","bytes","bytes","int"]',1017,7,'Armor System','',1),
(14,'list','["int","int","bytes","bytes","int"]',1018,7,'Structure System','',1),
(15,'list','["int","int","bytes","bytes","int"]',1019,7,'Powercore','',1),
(16,'list','["int","int","bytes","bytes","int"]',1020,7,'Capacitor Booster','',1),
(17,'list','["int","int","bytes","bytes","int"]',1021,7,'Propulsion','',1),
(18,'list','["int","int","bytes","bytes","int"]',1022,7,'Sensor System','',1),
(19,'list','["int","int","bytes","bytes","int"]',1023,7,'Cargo System','',1),
(20,'list','["int","int","bytes","bytes","int"]',1024,7,'Capsule System','',1),
(21,'list','["int","int","bytes","bytes","int"]',1025,8,'Ammo','',1),
(22,'list','["int","int","bytes","bytes","int"]',1026,8,'Missile','',1),
(23,'list','["int","int","bytes","bytes","int"]',1027,8,'Mine','',1),
(24,'list','["int","int","bytes","bytes","int"]',1028,10,'Mineral','',1),
(25,'list','["int","int","bytes","bytes","int"]',1029,25,'Ore','',1),
(26,'list','["int","int","bytes","bytes","int"]',1030,17,'Commodity','',1),
(27,'list','["int","int","bytes","bytes","int"]',26,6,'Cruiser','',1),
(28,'list','["int","int","bytes","bytes","int"]',27,6,'Battleship','',1),
(29,'list','["int","int","bytes","bytes","int"]',28,6,'Industrial','',1),
(30,'list','["int","int","bytes","bytes","int"]',100,18,'Combat Drone','',1),
(31,'list','["int","int","bytes","bytes","int"]',101,18,'Mining Drone','',1);
CREATE UNIQUE INDEX "pg_game_groups_0" ON "game_groups"("groupID");
CREATE  INDEX "pg_game_groups_1" ON "game_groups"("groupID");
COMMIT;
