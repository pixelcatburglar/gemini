-- Gemini 665 PostgreSQL table: game_handicaps
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_handicaps" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "handicapID" BIGINT,
  "physicalTraidID" BIGINT,
  "handicapName" TEXT,
  "description" TEXT,
  "numPoints" BIGINT,
  "points" BIGINT,
  "banCareerID" TEXT,
  "postAttributeID" TEXT,
  "postAttributeValue" TEXT,
  "postBonusTypeID" TEXT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_handicaps" ("_ordinal","_shape","_kinds","handicapID","physicalTraidID","handicapName","description","numPoints","points","banCareerID","postAttributeID","postAttributeValue","postBonusTypeID") VALUES
(0,'list','["int","int","bytes","bytes","int","int","none","none","none","none"]',1,1,'Handicap','',1,1,NULL,NULL,NULL,NULL);
CREATE  INDEX "pg_game_handicaps_0" ON "game_handicaps"("handicapID");
COMMIT;
