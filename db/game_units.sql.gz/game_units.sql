-- Gemini 665 PostgreSQL table: game_units
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_units" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "unitID" BIGINT,
  "unitName" TEXT,
  "displayName" TEXT,
  "description" TEXT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_units" ("_ordinal","_shape","_kinds","unitID","unitName","displayName","description") VALUES
(0,'list','["int","bytes","bytes","bytes"]',101,'Milliseconds','ms',''),
(1,'list','["int","bytes","bytes","bytes"]',102,'Percentage','%',''),
(2,'list','["int","bytes","bytes","bytes"]',103,'Modifier Percent','%',''),
(3,'list','["int","bytes","bytes","bytes"]',104,'Inversed Modifier Percent','%',''),
(4,'list','["int","bytes","bytes","bytes"]',105,'Inverse Absolute Percent','%',''),
(5,'list','["int","bytes","bytes","bytes"]',106,'Group ID','groupID',''),
(6,'list','["int","bytes","bytes","bytes"]',107,'Type ID','typeID',''),
(7,'list','["int","bytes","bytes","bytes"]',108,'Sizeclass','',''),
(8,'list','["int","bytes","bytes","bytes"]',109,'Mass','kg',''),
(9,'list','["int","bytes","bytes","bytes"]',110,'Volume','m3',''),
(10,'list','["int","bytes","bytes","bytes"]',111,'Speed','m/sec',''),
(11,'list','["int","bytes","bytes","bytes"]',112,'CPU','tf',''),
(12,'list','["int","bytes","bytes","bytes"]',113,'Power','MW','');
CREATE  INDEX "pg_game_units_0" ON "game_units"("unitID");
COMMIT;
