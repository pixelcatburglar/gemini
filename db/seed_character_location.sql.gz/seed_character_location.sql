-- Gemini 665 PostgreSQL table: seed_character_location
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "seed_character_location" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "characterID" BIGINT,
  "stationID" BIGINT,
  "solarSystemID" BIGINT,
  "constellationID" BIGINT,
  "regionID" BIGINT,
  "shipID" TEXT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "seed_character_location" ("_ordinal","_shape","_kinds","characterID","stationID","solarSystemID","constellationID","regionID","shipID") VALUES
(0,'dict','["int","int","int","int","int","none"]',90000001,64000055,30001381,20000202,10000020,NULL);
CREATE  INDEX "pg_seed_character_location_0" ON "seed_character_location"("characterID");
COMMIT;
