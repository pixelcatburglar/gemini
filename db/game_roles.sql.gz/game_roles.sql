-- Gemini 665 PostgreSQL table: game_roles
BEGIN;
SET standard_conforming_strings=on;
CREATE TABLE "game_roles" (
  "_ordinal" BIGINT,
  "_shape" TEXT NOT NULL,
  "_kinds" TEXT NOT NULL CHECK ("_kinds"::jsonb IS NOT NULL),
  "roleID" BIGINT,
  "roleName" TEXT,
  "shortDescription" TEXT,
  "description" TEXT,
  PRIMARY KEY ("_ordinal")
);
INSERT INTO "game_roles" ("_ordinal","_shape","_kinds","roleID","roleName","shortDescription","description") VALUES
(0,'list','["int","bytes","bytes","bytes"]',1,'roleDirector','Director',''),
(1,'list','["int","bytes","bytes","bytes"]',2,'rolePersonnelManager','Personnel Manager',''),
(2,'list','["int","bytes","bytes","bytes"]',4,'roleAccountant','Accountant',''),
(3,'list','["int","bytes","bytes","bytes"]',8,'roleStationManager','Station Manager',''),
(4,'list','["int","bytes","bytes","bytes"]',16,'roleFactoryManager','Factory Manager','');
CREATE  INDEX "pg_game_roles_0" ON "game_roles"("roleID");
COMMIT;
